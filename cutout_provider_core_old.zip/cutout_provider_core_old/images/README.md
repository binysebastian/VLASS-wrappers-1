**FITS Processing to JPEG**   
**NOTE: this is currently under construction and not finalized 2D output    

`python3 process_fits.py`

This takes whatever supported FITS files are in `data_out` and processes them into `.jpg`'s into `processed`.    
_All included surveys (see main README) are supported_   